package sample;

public class Static {
    public static String x ="";
}
